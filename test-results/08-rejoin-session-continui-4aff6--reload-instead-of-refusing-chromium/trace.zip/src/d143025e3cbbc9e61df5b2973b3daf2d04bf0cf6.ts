import { test, expect, openConsole, startOrRejoin } from './fixtures';

test.describe('session continuity', () => {
  test('rejoins the same session after a reload instead of refusing', async ({ page }) => {
    await openConsole(page);
    const first = await startOrRejoin(page);

    await openConsole(page);
    const second = await startOrRejoin(page);

    // One live session per address: starting again must land back on the
    // one already running, not 409 with no way forward.
    expect(second).toBe(first);
  });

  test('restores the workspace panels on a rejoin', async ({ page }) => {
    await openConsole(page);
    await startOrRejoin(page);

    await expect(page.locator('#fileList li').first()).toBeVisible({ timeout: 30_000 });
    await expect(page.locator('#serviceTabs .tab').first()).toBeVisible({ timeout: 30_000 });
    await expect(page.locator('#expiryTimer')).toHaveText(/left$/, { timeout: 30_000 });
  });
});
