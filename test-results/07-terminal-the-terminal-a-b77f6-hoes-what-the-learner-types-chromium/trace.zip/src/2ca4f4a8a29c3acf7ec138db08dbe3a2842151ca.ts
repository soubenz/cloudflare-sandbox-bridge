import { test as base, expect, type Page } from '@playwright/test';

export const API = process.env.OPALIX_URL || 'https://opalix-sandbox.soubenz94.workers.dev';

/**
 * A running lab session, shared by every spec in the run.
 *
 * Sessions are real containers, so the suite pays for exactly one. The
 * first spec to ask for it starts a lab; the rest land on the same session
 * because the API's dev start route rejoins the caller's live session
 * rather than refusing a second one. That makes the fixture cheap and
 * incidentally exercises rejoin on every file.
 *
 * The session is torn down by zz-teardown.spec.ts, which ends it through
 * the UI — cleanup and a test of the end-session flow in one, so a leaked
 * container cannot outlive the run silently.
 */
type Fixtures = {
  /** The console, with a session running and the workspace on screen. */
  session: Page;
};

export const test = base.extend<Fixtures>({
  session: async ({ page }, use) => {
    await openConsole(page);
    await startOrRejoin(page);
    await use(page);
  },
});

/** Loads the console and points it at the API under test. */
export async function openConsole(page: Page): Promise<void> {
  await page.goto('/', { waitUntil: 'domcontentloaded' });
  await page.evaluate((api) => localStorage.setItem('opalix.apiBase', api), API);
  await page.reload({ waitUntil: 'domcontentloaded' });
}

/** Starts the `hello` lab, or rejoins the session this address already has. */
export async function startOrRejoin(page: Page): Promise<string> {
  await page.waitForSelector('.lab', { timeout: 30_000 });
  await page.locator('.lab', { hasText: 'hello' }).first().locator('button').click();

  await page.waitForSelector('#workspace:not([hidden])', { timeout: 30_000 });
  await expect(page.locator('#statePill')).toHaveText('running', { timeout: 120_000 });

  return (await page.locator('#sessionId').textContent()) ?? '';
}

/**
 * True when the network between here and the API strips the WebSocket
 * handshake headers. `Upgrade` and `Connection` are hop-by-hop, so a proxy
 * that re-issues rather than tunnels the request drops them and the Worker
 * then refuses to return a WebSocket at all. That is a property of the
 * network, not of the console, so terminal specs skip rather than fail —
 * but only on that specific evidence, so a genuinely broken terminal still
 * reports as broken.
 */
export function upgradeHeaderStripped(consoleErrors: string[]): boolean {
  return consoleErrors.some((e) => /WebSocket handshake: Unexpected response code: 500/.test(e));
}

/** Collects browser console errors for the life of a page. */
export function collectConsoleErrors(page: Page): string[] {
  const errors: string[] = [];
  page.on('console', (msg) => {
    if (msg.type() === 'error') errors.push(msg.text());
  });
  page.on('pageerror', (err) => errors.push(`pageerror: ${err.message}`));
  return errors;
}

export { expect };
